# alien-pcre2
Alien::PCRE2, Use Perl To Build The New Perl Compatible Regular Expression Engine On Any Platform
